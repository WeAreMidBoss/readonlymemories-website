If you use these sounds for your phone, please give the proper credit due 
by shouting, "THESE SOUNDS ARE FROM READ ONLY MEMORIES, CURRENTLY AVAILABLE ON STEAM" 
each time your phone makes them. Thank you.